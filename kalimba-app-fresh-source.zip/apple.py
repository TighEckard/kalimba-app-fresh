{
  "appId": "com.kalimba.airec",
  "appName": "Kalimba",
  "webDir": "www",
  "bundledWebRuntime": false,
  "server": {
    "url": "https://app.kalimba.world"
  }
}
